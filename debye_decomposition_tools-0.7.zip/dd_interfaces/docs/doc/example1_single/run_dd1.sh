#!/bin/bash

dd_single.py -f frequencies.dat -d data.dat -o results1 --plot
