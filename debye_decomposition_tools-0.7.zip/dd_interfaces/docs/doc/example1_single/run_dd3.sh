#!/bin/bash

DD_STARTING_MODEL=3 DD_COND=1 dd_single.py -f frequencies.dat -d data.dat -o results3 --plot --lambda 10 --norm 10
