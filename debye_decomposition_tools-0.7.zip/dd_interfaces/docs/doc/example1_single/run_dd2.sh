#!/bin/bash

DD_STARTING_MODEL=3 dd_single.py -f frequencies.dat -d data.dat -o results2 --plot --lambda 10
