lib_dd package
==============

Subpackages
-----------

.. toctree::

    lib_dd.conductivity
    lib_dd.io

Submodules
----------

lib_dd.Jacobian module
----------------------

.. automodule:: lib_dd.Jacobian
    :members:
    :undoc-members:
    :show-inheritance:

lib_dd.base_class module
------------------------

.. automodule:: lib_dd.base_class
    :members:
    :undoc-members:
    :show-inheritance:

lib_dd.colecole module
----------------------

.. automodule:: lib_dd.colecole
    :members:
    :undoc-members:
    :show-inheritance:

lib_dd.dd_res_base_log10rho0_log10m module
------------------------------------------

.. automodule:: lib_dd.dd_res_base_log10rho0_log10m
    :members:
    :undoc-members:
    :show-inheritance:

lib_dd.dd_res_base_rho0_log10m module
-------------------------------------

.. automodule:: lib_dd.dd_res_base_rho0_log10m
    :members:
    :undoc-members:
    :show-inheritance:

lib_dd.dd_res_base_rho0_m module
--------------------------------

.. automodule:: lib_dd.dd_res_base_rho0_m
    :members:
    :undoc-members:
    :show-inheritance:

lib_dd.dd_res_data_log10re_mim module
-------------------------------------

.. automodule:: lib_dd.dd_res_data_log10re_mim
    :members:
    :undoc-members:
    :show-inheritance:

lib_dd.int_pars module
----------------------

.. automodule:: lib_dd.int_pars
    :members:
    :undoc-members:
    :show-inheritance:

lib_dd.interface module
-----------------------

.. automodule:: lib_dd.interface
    :members:
    :undoc-members:
    :show-inheritance:

lib_dd.main module
------------------

.. automodule:: lib_dd.main
    :members:
    :undoc-members:
    :show-inheritance:

lib_dd.plot module
------------------

.. automodule:: lib_dd.plot
    :members:
    :undoc-members:
    :show-inheritance:

lib_dd.sample_data module
-------------------------

.. automodule:: lib_dd.sample_data
    :members:
    :undoc-members:
    :show-inheritance:

lib_dd.test_functions module
----------------------------

.. automodule:: lib_dd.test_functions
    :members:
    :undoc-members:
    :show-inheritance:

lib_dd.version module
---------------------

.. automodule:: lib_dd.version
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: lib_dd
    :members:
    :undoc-members:
    :show-inheritance:
