.. DD_Interfaces documentation master file, created by
   sphinx-quickstart on Mon Jun 17 09:29:21 2013.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

=============
DD_Interfaces
=============

.. toctree::
    :maxdepth: 3

    introduction
    installation
    getting_started
    fit_routines
    theory
    inversion
    usage_and_implementation
    debugging
    api


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
