This directory contains decomposition results of various SIP signatures
produced with one or two-term Cole-Cole models.
