Description
-----------

Generate CC models with linearly increasing m_cc values

Analysis
--------

- inspect spectra for malbehaviour
- inspect 'plots_stats/' subdirectory

We expect a linearly increasing m_tot/m_tot_n distribution over time.
