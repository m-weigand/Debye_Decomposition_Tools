Description
-----------

Generate CC models with constant m_cc values

Analysis
--------

- inspect spectra for malbehaviour
- inspect 'plots_stats/' subdirectory

We expect a constant m_tot/m_tot_n distribution over time.
