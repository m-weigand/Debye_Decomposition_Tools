Tests in this directory test the normalization feature
