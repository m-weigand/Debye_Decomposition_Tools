"""
Overview lib_dd package
"""
