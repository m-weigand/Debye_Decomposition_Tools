from .resistivity import cc_res as cc_res
from .decomposition_res import decomposition_resistivity

all = [cc_res, decomposition_resistivity]
