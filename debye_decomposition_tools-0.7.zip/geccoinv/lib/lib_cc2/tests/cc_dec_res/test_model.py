#!/usr/bin/python

import lib_cc2.decomposition_res as dr
print dir(dr)
obj = dr.dec_res()
