from NDimInv.plot_helper import *
import numpy as np

# generate data to be fitted
x = np.arange(1, 2, 0.05)
y = 2.0 * np.exp(x * 2.0)
np.random.seed(5)
y += np.random.uniform(0, 5, x.size)

fig, ax = plt.subplots(1, 1)
ax.plot(x, y, '.-', label='data')
ax.legend()
ax.set_xlabel('x')
ax.set_ylabel('y')