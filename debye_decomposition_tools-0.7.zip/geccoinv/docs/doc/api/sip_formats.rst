sip_formats package
===================

Submodules
----------

sip_formats.convert module
--------------------------

.. automodule:: sip_formats.convert
    :members:
    :undoc-members:
    :show-inheritance:

sip_formats.test_convert module
-------------------------------

.. automodule:: sip_formats.test_convert
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: sip_formats
    :members:
    :undoc-members:
    :show-inheritance:
