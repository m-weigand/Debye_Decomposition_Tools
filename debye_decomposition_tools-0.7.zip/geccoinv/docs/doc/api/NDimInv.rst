NDimInv package
===============

Submodules
----------

NDimInv.ND_Data module
----------------------

.. automodule:: NDimInv.ND_Data
    :members:
    :undoc-members:
    :show-inheritance:

NDimInv.ND_Model module
-----------------------

.. automodule:: NDimInv.ND_Model
    :members:
    :undoc-members:
    :show-inheritance:

NDimInv.data_weighting module
-----------------------------

.. automodule:: NDimInv.data_weighting
    :members:
    :undoc-members:
    :show-inheritance:

NDimInv.elem module
-------------------

.. automodule:: NDimInv.elem
    :members:
    :undoc-members:
    :show-inheritance:

NDimInv.helper module
---------------------

.. automodule:: NDimInv.helper
    :members:
    :undoc-members:
    :show-inheritance:

NDimInv.main module
-------------------

.. automodule:: NDimInv.main
    :members:
    :undoc-members:
    :show-inheritance:

NDimInv.model_template module
-----------------------------

.. automodule:: NDimInv.model_template
    :members:
    :undoc-members:
    :show-inheritance:

NDimInv.plot_helper module
--------------------------

.. automodule:: NDimInv.plot_helper
    :members:
    :undoc-members:
    :show-inheritance:

NDimInv.reg_pars module
-----------------------

.. automodule:: NDimInv.reg_pars
    :members:
    :undoc-members:
    :show-inheritance:

NDimInv.regs module
-------------------

.. automodule:: NDimInv.regs
    :members:
    :undoc-members:
    :show-inheritance:

NDimInv.version module
----------------------

.. automodule:: NDimInv.version
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: NDimInv
    :members:
    :undoc-members:
    :show-inheritance:
