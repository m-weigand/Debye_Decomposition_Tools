lib_cc2 package
===============

Submodules
----------

lib_cc2.decomp_em_res module
----------------------------

.. automodule:: lib_cc2.decomp_em_res
    :members:
    :undoc-members:
    :show-inheritance:

lib_cc2.decomposition_res module
--------------------------------

.. automodule:: lib_cc2.decomposition_res
    :members:
    :undoc-members:
    :show-inheritance:

lib_cc2.resistivity module
--------------------------

.. automodule:: lib_cc2.resistivity
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: lib_cc2
    :members:
    :undoc-members:
    :show-inheritance:
