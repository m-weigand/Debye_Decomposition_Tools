This directory serves as a plaground for new ideas or studies. They reside here
until they are polished enough to be moved to another directory.
