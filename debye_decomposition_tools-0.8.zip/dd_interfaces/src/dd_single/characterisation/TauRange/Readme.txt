Introduction
============

The tests/characterizations in this directory deal with the behaviour of the
Debye Decomposition depending on the range of tau values used for the
inversion.

Usage
=====
