Specialised tests for certain functions
