#!/bin/bash

find . -name "run_dd.sh" -execdir bash run_dd.sh \;
