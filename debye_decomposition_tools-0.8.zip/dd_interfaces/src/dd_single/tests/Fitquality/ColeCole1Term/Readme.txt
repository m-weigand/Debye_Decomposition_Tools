Record the fit quality of the single term Cole-Cole models used in ../../Colecole1Term/

The script "generate_rawdata.py" was used to initially generate the data sets.
