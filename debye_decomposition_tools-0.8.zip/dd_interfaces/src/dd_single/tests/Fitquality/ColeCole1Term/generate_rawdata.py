#!/usr/bin/python
# -*- coding: utf-8 -*-
"""

"""
import sys
sys.path.append('../../ColeCole1Term')
import test_cases

test_cases.generate_all_spectra()
