Most of the time a successful fit depends on a good starting model. It turned
out that one-term Cole-Cole spectra are a simple way to test starting models.
Just vary m, tau, and c.
