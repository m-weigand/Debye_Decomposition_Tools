Introduction
============
Each (sub-)directory contains one data.dat and one frequencies.dat file to be fitted.

Usage
=====
To run all tests, execute

# nosetests -s -v test_cases.py
