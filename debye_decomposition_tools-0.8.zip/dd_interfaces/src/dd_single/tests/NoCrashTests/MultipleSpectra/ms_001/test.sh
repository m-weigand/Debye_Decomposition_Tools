#!/bin/bash


dd_single.py -f frequencies.dat -d data.dat --plot -o results -n 20 --tmp --silent
