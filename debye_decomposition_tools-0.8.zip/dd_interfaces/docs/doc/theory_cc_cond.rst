Cole-Cole decomposition conductivities
======================================

complex
-------
After Tarasov and Titov, 2013:


.. math::

    \hat{\sigma}(\omega) &= \sigma_\infty \left(1 - \sum_k\frac{m_k}{1 + (j
    \omega \tau_k)^c}\right)\\
    m &= \frac{\sigma_\infty - \sigma_0}{\sigma_\infty}\\
    \sigma_0 &= (1 - m) \cdot \sigma_\infty
