Theory of SIP models
====================


.. toctree::
    :maxdepth: 2

    theory_overview
    theory_dd_res
    theory_dd_cond
    theory_cc_res
    theory_cc_cond
    dd_theory_eps
    dd_coverage
    dd_general
    integral_parameters
