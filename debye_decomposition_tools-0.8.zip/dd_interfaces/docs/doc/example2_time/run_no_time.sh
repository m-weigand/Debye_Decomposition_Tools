#!/bin/bash

dd_time.py -f data/frequencies.dat\
 --times data/times.dat\
 -d data/data.dat\
 -o "results_no_time"\
 --f_lambda 50\
 --tm_i_lambda 0\
 --trho0_lambda 0\
 --plot
