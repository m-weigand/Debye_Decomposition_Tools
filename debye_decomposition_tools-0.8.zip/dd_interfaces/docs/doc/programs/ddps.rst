ddps.py
-------

.. note::

    *ddps.py* only works with the ascii output format!

Command line options
^^^^^^^^^^^^^^^^^^^^

.. program-output:: ddps.py -h
