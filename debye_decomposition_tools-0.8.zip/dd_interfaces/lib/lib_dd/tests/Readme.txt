
nosetests -s -v --with-coverage --cover-package lib_dd test*.py
